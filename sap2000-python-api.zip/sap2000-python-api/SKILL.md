---
name: sap2000-python-api
description: 用于自动化 SAP2000 建筑结构分析任务的 Python API skill。当用户需要进行以下操作时使用此 skill：使用 Python 通过 COM 接口控制 SAP2000 进行结构分析；创建或修改 SAP2000 模型（包括材料定义、截面定义、几何对象创建等）；施加荷载和边界条件；运行结构分析；提取分析结果（位移、内力、应力等）；批量参数化分析；从其他程序（如 Excel、MATLAB）调用 SAP2000；编写 SAP2000 API 自动化脚本。即使没有明确提及 SAP2000 或 API，如果涉及结构分析自动化、有限元软件自动化、建筑结构建模等工作，也应考虑使用此 skill。
---

# SAP2000 Python API 自动化 Skill

本 skill 提供使用 Python 自动化 SAP2000 结构分析软件的完整指导。SAP2000 是通用的结构分析设计软件，广泛应用于建筑结构、桥梁、工业设施等工程领域。

## 📚 参考文档

本 skill 包含以下详细的参考文档，用于快速查找常用信息：

### 1. [常用材料属性参考表](references/common_materials.md)
- C20-C50 混凝土材料参数（弹性模量、重度等）
- Q235-Q460 钢材材料参数
- 单位换算公式
- 常见错误和注意事项
- **何时使用**: 需要定义材料时，快速查找正确的材料参数

### 2. [单位系统详细说明](references/unit_systems.md)
- 各种单位系统代码和适用场景
- kN-m-C 系统下的典型数值范围
- 完整的单位换算公式
- 常见单位错误和避免方法
- **何时使用**: 确保输入值单位正确，避免最常见的错误

### 3. [局部坐标系说明](references/local_coordinate_system.md)
- 框架对象的局部坐标系定义
- 梁和柱的坐标轴方向
- 内力分量（P, V2, V3, M2, M3）的含义
- 荷载方向代码说明
- **何时使用**: 施加荷载或提取内力时，确保使用正确的方向

### 4. [结果提取实用示例](references/result_extraction_examples.md)
- 提取所有节点位移
- 提取所有梁控制内力
- 多工况结果提取
- 导出到 Excel
- 找最不利位置
- **何时使用**: 需要从 SAP2000 提取和分析结果时

## 前置要求

### 环境配置

在开始使用 SAP2000 Python API 之前，需要：

1. **安装 SAP2000**：
   - 确保已安装 SAP2000（版本 15 或更高）
   - 记住 SAP2000.exe 的安装路径

2. **安装 Python**：
   - 推荐 Python 3.9 或更高版本
   - Windows 系统推荐从 python.org 下载安装

3. **安装 comtypes 库**：
   ```bash
   pip install comtypes
   ```

### 重要提示

- SAP2000 必须安装在开发机和最终用户的机器上
- 本 skill 基于 SAP2000 v26.0.0 API 文档
- 使用 .NET Standard 2.0 DLL 或 COM 接口
- 建议使用 COM 接口（通过 comtypes），兼容性更好

## 连接到 SAP2000

### 基本连接模式

```python
import comtypes.client
import os

# 创建 Helper 对象
helper = comtypes.client.CreateObject('SAP2000v1.Helper')
helper = helper.QueryInterface(comtypes.gen.SAP2000v1.cHelper)

# 连接模式选择
AttachToInstance = False  # True=连接到现有实例，False=启动新实例
SpecifyPath = False       # True=指定路径，False=使用最新安装版本

if AttachToInstance:
    # 连接到已运行的 SAP2000 实例
    try:
        mySapObject = helper.GetObject("CSI.SAP2000.API.SapObject")
    except (OSError, comtypes.COMError):
        print("未找到运行中的 SAP2000 实例")
        sys.exit(-1)
else:
    if SpecifyPath:
        # 从指定路径启动 SAP2000
        ProgramPath = r'C:\Program Files\Computers and Structures\SAP2000 26\SAP2000.exe'
        try:
            mySapObject = helper.CreateObject(ProgramPath)
        except (OSError, comtypes.COMError):
            print(f"无法从 {ProgramPath} 启动 SAP2000")
            sys.exit(-1)
    else:
        # 启动最新安装版本的 SAP2000
        try:
            mySapObject = helper.CreateObjectProgID("CSI.SAP2000.API.SapObject")
        except (OSError, comtypes.COMError):
            print("无法启动 SAP2000")
            sys.exit(-1)

# 启动 SAP2000 应用程序
mySapObject.ApplicationStart()

# 获取 SapModel 对象
SapModel = mySapObject.SapModel
```

### 完整连接示例

```python
import os
import sys
import comtypes.client

def connect_to_sap2000(attach_to_instance=False, program_path=None):
    """
    连接到 SAP2000

    参数:
        attach_to_instance: 是否连接到已运行的实例
        program_path: SAP2000.exe 的路径（如果为 None，使用最新安装版本）

    返回:
        (SapObject, SapModel) 元组
    """
    # 创建 Helper 对象
    helper = comtypes.client.CreateObject('SAP2000v1.Helper')
    helper = helper.QueryInterface(comtypes.gen.SAP2000v1.cHelper)

    if attach_to_instance:
        # 连接到现有实例
        try:
            sap_object = helper.GetObject("CSI.SAP2000.API.SapObject")
        except (OSError, comtypes.COMError):
            raise Exception("未找到运行中的 SAP2000 实例")
    else:
        if program_path:
            # 从指定路径启动
            try:
                sap_object = helper.CreateObject(program_path)
            except (OSError, comtypes.COMError):
                raise Exception(f"无法从 {program_path} 启动 SAP2000")
        else:
            # 启动最新版本
            try:
                sap_object = helper.CreateObjectProgID("CSI.SAP2000.API.SapObject")
            except (OSError, comtypes.COMError):
                raise Exception("无法启动 SAP2000")

    # 启动应用程序
    sap_object.ApplicationStart()

    # 获取 SapModel
    sap_model = sap_object.SapModel

    return sap_object, sap_model

def disconnect_from_sap2000(sap_object, sap_model):
    """
    断开与 SAP2000 的连接

    参数:
        sap_object: SAP2000 对象
        sap_model: SapModel 对象
    """
    # 退出应用程序（不保存模型）
    sap_object.ApplicationExit(False)

    # 释放对象（非常重要！）
    sap_model = None
    sap_object = None
```

## 模型操作

### 初始化新模型

```python
# 初始化新模型
ret = SapModel.InitializeNewModel()

# 创建新的空白模型
ret = SapModel.File.NewBlank()

# 或使用模板创建模型
# PortalFrame = 1
# ret = SapModel.File.New2DFrame(PortalFrame, 3, 124, 3, 200)
```

### 打开和保存模型

```python
# 打开现有模型
model_path = r'C:\Models\MyStructure.sdb'
ret = SapModel.File.OpenFile(model_path)

# 保存模型
ret = SapModel.File.Save(model_path)

# 另存为
ret = SapModel.File.Save(r'C:\Models\MyStructure_Backup.sdb')
```

## 单位系统

SAP2000 使用多种单位系统，常见单位代码：

```python
# 单位常量
kip_in_F = 3       # kip, in, F
kip_ft_F = 4       # kip, ft, F
kN_mm_C = 6        # kN, mm, C
kN_m_C = 7         # kN, m, C
kgf_mm_C = 9       # kgf, mm, C
kgf_m_C = 10       # kgf, m, C
N_mm_C = 11        # N, mm, C
N_m_C = 12         # N, m, C

# 设置当前单位
ret = SapModel.SetPresentUnits(kN_m_C)

# 获取当前单位
units = SapModel.GetPresentUnits()
```

## 材料属性定义

### 定义材料

```python
# 材料类型常量
MATERIAL_STEEL = 1
MATERIAL_CONCRETE = 2
MATERIAL_NONE = 3
MATERIAL_ALUMINUM = 4
MATERIAL_COLD_FORMED = 5
MATERIAL_REBAR = 6
MATERIAL_TENDON = 7

# 创建材料
material_name = "CONC"
material_type = MATERIAL_CONCRETE
ret = SapModel.PropMaterial.SetMaterial(material_name, material_type)
```

### 设置材料属性

```python
# 设置各向同性材料属性
# 参数: 材料名称, 弹性模量, 泊松比, 热膨胀系数
# 单位取决于当前单位系统
ret = SapModel.PropMaterial.SetMPIsotropic('CONC', 3600, 0.2, 0.0000055)

# 设置材料基本属性
# 参数: 材料名称, 密度, 重度 (单位取决于当前单位系统)
ret = SapModel.PropMaterial.SetWeightAndMass('CONC', 0.00015, 2.4)

# 获取材料属性
[elastic_modulus, poisson_ratio, thermal_coeff, ret] = \
    SapModel.PropMaterial.GetMPIsotropic('CONC')
```

## 截面属性定义

### 框架截面

```python
# 定义矩形截面
# 参数: 截面名称, 材料名称, 高度, 宽度
ret = SapModel.PropFrame.SetRectangle('R1', 'CONC', 12, 12)

# 定义圆形截面
# 参数: 截面名称, 材料名称, 直径
ret = SapModel.PropFrame.SetCircle('C1', 'CONC', 18)

# 定义工字形截面 (钢截面)
# 参数: 截面名称, 材料名称, 高度, 上翼缘宽度, 上翼缘厚度,
#       腹板厚度, 下翼缘宽度, 下翼缘厚度
ret = SapModel.PropFrame.SetISection('I1', 'STEEL', 24, 12, 0.5, 0.3, 12, 0.5)

# 设置截面修正系数
# 用于考虑开裂、有效宽度等因素
# 参数: 8个修正系数 [Area, ShearArea2, ShearArea3, TorsionalConstant,
#       MomentOfInertia2, MomentOfInertia3, Mass, Weight]
mod_value = [1000, 0, 0, 1, 1, 1, 1, 1]
ret = SapModel.PropFrame.SetModifiers('R1', mod_value)
```

## 几何对象创建

### 点对象（节点）

```python
# 添加点对象
# 参数: x, y, z 坐标
point_name = ''  # 空字符串表示让 SAP2000 自动命名
name, ret = SapModel.PointObj.AddCartesian(0, 0, 0, point_name)

# 批量添加点
points = [
    (0, 0, 0),
    (0, 0, 3000),
    (4000, 0, 3000),
    (4000, 0, 0)
]

point_names = []
for x, y, z in points:
    name, ret = SapModel.PointObj.AddCartesian(x, y, z, '')
    point_names.append(name)
```

### 框架对象（梁/柱）

```python
# 通过坐标添加框架对象
# 参数: x1, y1, z1, x2, y2, z2, 名称, 截面, 名称(点对象), 坐标系
frame_name = ''
[FrameName1, ret] = SapModel.FrameObj.AddByCoord(
    0, 0, 0,          # 起点 I
    0, 0, 3000,       # 终点 J
    frame_name,       # 名称（空表示自动命名）
    'R1',             # 截面属性
    '1',              # 点对象名称
    'Global'          # 坐标系
)

# 通过点名添加框架对象
# 参数: 点1名称, 点2名称, 名称, 截面, 坐标系
frame_name, ret = SapModel.FrameObj.AddByPoint(
    'Point1', 'Point2', '', 'R1', 'Global'
)

# 修改框架对象属性
ret = SapModel.FrameObj.SetSection('Frame1', 'R1')  # 修改截面
```

### 面对象（板/壳）

```python
# 通过坐标添加面对象
# 参数: x, y, z 坐标数组, 名称, 截面, 名称(点对象), 坐标系
area_name = ''
coords = [0, 0, 0, 4, 0, 0, 4, 3, 0, 0, 3, 0]  # 4个点
[AreaName, ret] = SapModel.AreaObj.AddByCoord(
    coords,
    area_name,
    'SLAB1',    # 截面属性
    '',         # 点对象名称
    'Global'    # 坐标系
)
```

## 边界条件

### 设置支座约束

```python
# 约束类型 [U1, U2, U3, R1, R2, R3]
# True = 固定, False = 自由

# 固定支座（全部约束）
restraint = [True, True, True, True, True, True]
ret = SapModel.PointObj.SetRestraint('Point1', restraint)

# 铰支座（仅约束平动）
restraint = [True, True, True, False, False, False]
ret = SapModel.PointObj.SetRestraint('Point2', restraint)

# 滚动支座（约束竖向和转动）
restraint = [False, True, False, True, True, True]
ret = SapModel.PointObj.SetRestraint('Point3', restraint)

# 固定悬臂端（约束全部转动）
restraint = [False, False, False, True, True, True]
ret = SapModel.PointObj.SetRestraint('Point4', restraint)
```

### 获取和修改约束

```python
# 获取约束
restraint, ret = SapModel.PointObj.GetRestraint('Point1')

# 释放框架端部
# 参数: 框架名称, 端部(True=起点I, False=终点J), 释放标识
# Release: [U1, U2, U3, R1, R2, R3]
release = [False, False, False, False, True, False]  # 释放M2
ret = SapModel.FrameObj.SetReleases('Frame1', True, release)
```

## 荷载定义

### 荷载模式

```python
# 荷载类型常量
LTYPE_DEAD = 1        # 恒载
LTYPE_LIVE = 2        # 活载
LTYPE_QUAKE = 3       # 地震荷载
LTYPE_WIND = 4        # 风荷载
LTYPE_SNOW = 5        # 雪荷载
LTYPE_OTHER = 8       # 其他荷载

# 添加荷载模式
# 参数: 名称, 类型, 自重系数, 添加到分析
ret = SapModel.LoadPatterns.Add('DEAD', LTYPE_DEAD, 1, True)
ret = SapModel.LoadPatterns.Add('LIVE', LTYPE_LIVE, 0, True)
ret = SapModel.LoadPatterns.Add('WIND', LTYPE_WIND, 0, True)
```

### 点荷载

```python
# 施加点荷载
# 参数: 点名称, 荷载模式, 荷载值 [F1, F2, F3, M1, M2, M3]
point_load = [0, 0, -10, 0, 0, 0]  # 10 kN 向下
ret = SapModel.PointObj.SetLoadForce('Point1', 'LIVE', point_load)

# 获取点荷载
[load, ret] = SapModel.PointObj.GetLoadForce('Point1', 'LIVE')

# 删除点荷载
ret = SapModel.PointObj.DeleteLoad('Point1', 'LIVE')
```

### 框架分布荷载

```python
# 添加分布荷载
# 参数: 框架名称, 荷载模式, 荷载类型, 方向,
#       相对距离I, 相对距离J, 荷载值I, 荷载值J, 坐标系
# 荷载类型: 1=力, 2=弯矩
# 方向: 1=Local1(轴向), 2=Local2(剪切), 3=Local3(横向)

# 均布荷载 (力)
ret = SapModel.FrameObj.SetLoadDistributed(
    'Frame1',      # 框架名称
    'LIVE',        # 荷载模式
    1,             # 荷载类型: 力
    2,             # 方向: Local2
    0,             # 相对距离I (0=起点)
    1,             # 相对距离J (1=终点)
    5,             # 荷载值I (5 kN/m)
    5,             # 荷载值J
    'Local'        # 坐标系
)

# 梯形分布荷载
ret = SapModel.FrameObj.SetLoadDistributed(
    'Frame2', 'LIVE', 1, 2, 0, 1, 3, 7, 'Local'  # 从3到7 kN/m
)

# 横向均布荷载 (kN/m)
ret = SapModel.FrameObj.SetLoadDistributed(
    'Frame3', 'WIND', 1, 3, 0, 1, 2, 2, 'Local'
)
```

### 框架点荷载

```python
# 在框架上施加集中荷载
# 参数: 框架名称, 荷载模式, 荷载类型, 方向,
#       相对距离, 荷载值, 坐标系
ret = SapModel.FrameObj.SetLoadPoint(
    'Frame1',      # 框架名称
    'LIVE',        # 荷载模式
    1,             # 荷载类型: 力
    2,             # 方向: Local2
    0.5,           # 相对距离 (0.5 = 跨中)
    -15,           # 荷载值 (15 kN)
    'Local'        # 坐标系
)
```

## 分析运行

### 运行分析

```python
# 设置分析选项
# 锁定模型
ret = SapModel.SetModelIsLocked(True)

# 运行分析
ret = SapModel.Analyze.RunAnalysis()

# 检查分析是否完成
if ret == 0:
    print("分析成功完成")
else:
    print(f"分析失败，错误代码: {ret}")

# 解锁模型（修改前需要）
ret = SapModel.SetModelIsLocked(False)
```

### 分析工况设置

```python
# 获取分析工况数量
[n_cases, ret] = SapModel.LoadCases.Count()

# 获取分析工况名称
case_names = []
for i in range(1, n_cases + 1):
    name, ret = SapModel.LoadCases.GetName(i)
    case_names.append(name)
```

## 结果提取

### 设置输出选项

```python
# 选择要提取结果的工况
ret = SapModel.Results.Setup.DeselectAllCasesAndCombosForOutput()
ret = SapModel.Results.Setup.SetCaseSelectedForOutput('DEAD')
ret = SapModel.Results.Setup.SetCaseSelectedForOutput('LIVE')
```

### 节点位移

```python
# 获取节点位移
# 参数: 节点名称, 对象类型, 结果数量数组等
object_elm = 0  # 0=对象, 1=单元

# 获取某个节点的位移
[NumberResults, Obj, Elm, ACase, StepType, StepNum,
 U1, U2, U3, R1, R2, R3, ret] = \
    SapModel.Results.JointDispl(
        'Point1',          # 节点名称
        object_elm,        # 对象/单元标志
        0, [], [], [], [], [],  # 输出数组（初始化）
        [], [], [], [], []
    )

if NumberResults > 0:
    for i in range(NumberResults):
        print(f"工况: {ACase[i]}")
        print(f"  U1: {U1[i]:.6f}")
        print(f"  U2: {U2[i]:.6f}")
        print(f"  U3: {U3[i]:.6f}")
```

### 框架内力

```python
# 获取框架内力
# 返回: 结果数量, 对象, 单元, 工况, 步类型, 步数,
#       位置, P, V2, V3, T, M2, M3
[NumberResults, Obj, Elm, ACase, StepType, StepNum,
 Loc, P, V2, V3, T, M2, M3, ret] = \
    SapModel.Results.FrameForce(
        'Frame1',
        object_elm,
        0, [], [], [], [], [],  # 输出数组
        [], [], [], [], [], [], []
    )

if NumberResults > 0:
    for i in range(NumberResults):
        print(f"工况: {ACase[i]}, 位置: {Loc[i]:.3f}")
        print(f"  轴力 P: {P[i]:.2f}")
        print(f"  剪力 V2: {V2[i]:.2f}")
        print(f"  剪力 V3: {V3[i]:.2f}")
        print(f"  扭矩 T: {T[i]:.2f}")
        print(f"  弯矩 M2: {M2[i]:.2f}")
        print(f"  弯矩 M3: {M3[i]:.2f}")
```

### 批量提取结果

```python
def extract_all_frame_results(sap_model, frame_names, load_cases):
    """
    提取所有框架的内力结果

    参数:
        sap_model: SapModel 对象
        frame_names: 框架名称列表
        load_cases: 荷载工况列表

    返回:
        结果字典
    """
    results = {}

    for frame_name in frame_names:
        results[frame_name] = {}

        # 选择输出工况
        sap_model.Results.Setup.DeselectAllCasesAndCombosForOutput()
        for case in load_cases:
            sap_model.Results.Setup.SetCaseSelectedForOutput(case)

        # 获取结果
        [n, Obj, Elm, ACase, StepType, StepNum,
         Loc, P, V2, V3, T, M2, M3, ret] = \
            sap_model.Results.FrameForce(frame_name, 0, 0, [], [], [], [],
                                        [], [], [], [], [], [], [])

        for i in range(n):
            case = ACase[i]
            if case not in results[frame_name]:
                results[frame_name][case] = {
                    'Loc': [], 'P': [], 'V2': [], 'V3': [],
                    'T': [], 'M2': [], 'M3': []
                }

            results[frame_name][case]['Loc'].append(Loc[i])
            results[frame_name][case]['P'].append(P[i])
            results[frame_name][case]['V2'].append(V2[i])
            results[frame_name][case]['V3'].append(V3[i])
            results[frame_name][case]['T'].append(T[i])
            results[frame_name][case]['M2'].append(M2[i])
            results[frame_name][case]['M3'].append(M3[i])

    return results
```

## 批量参数化分析

### 参数化建模示例

```python
def parametric_frame_analysis(widths, heights, loads, output_dir):
    """
    参数化框架分析

    参数:
        widths: 跨度列表 [m]
        heights: 层高列表 [m]
        loads: 荷载列表 [kN/m]
        output_dir: 输出目录
    """
    # 连接到 SAP2000
    sap_object, sap_model = connect_to_sap2000()

    results = []

    for i, (width, height, load) in enumerate(zip(widths, heights, loads)):
        print(f"分析模型 {i+1}: 宽={width}m, 高={height}m, 荷载={load}kN/m")

        # 初始化模型
        sap_model.InitializeNewModel()
        sap_model.File.NewBlank()

        # 设置单位 (kN, m)
        sap_model.SetPresentUnits(7)  # kN_m_C

        # 定义材料和截面
        sap_model.PropMaterial.SetMaterial('CONC', 2)
        sap_model.PropMaterial.SetMPIsotropic('CONC', 36000, 0.2, 1e-5)
        sap_model.PropFrame.SetRectangle('COL', 'CONC', 0.4, 0.4)
        sap_model.PropFrame.SetRectangle('BEAM', 'CONC', 0.3, 0.5)

        # 创建节点
        [p1, _] = sap_model.PointObj.AddCartesian(0, 0, 0, '')
        [p2, _] = sap_model.PointObj.AddCartesian(0, 0, height, '')
        [p3, _] = sap_model.PointObj.AddCartesian(width, 0, height, '')
        [p4, _] = sap_model.PointObj.AddCartesian(width, 0, 0, '')

        # 创建框架
        [col1, _] = sap_model.FrameObj.AddByPoint(p1, p2, '', 'COL', 'Global')
        [beam, _] = sap_model.FrameObj.AddByPoint(p2, p3, '', 'BEAM', 'Global')
        [col2, _] = sap_model.FrameObj.AddByPoint(p3, p4, '', 'COL', 'Global')

        # 施加约束
        restraint = [True, True, True, True, True, True]
        sap_model.PointObj.SetRestraint(p1, restraint)
        sap_model.PointObj.SetRestraint(p4, restraint)

        # 施加荷载
        sap_model.LoadPatterns.Add('LIVE', 8, 0, True)
        sap_model.FrameObj.SetLoadDistributed(beam, 'LIVE', 1, 3, 0, 1, load, load, 'Local')

        # 运行分析
        model_path = f"{output_dir}/model_{i+1}.sdb"
        sap_model.File.Save(model_path)
        sap_model.Analyze.RunAnalysis()

        # 提取结果
        sap_model.Results.Setup.DeselectAllCasesAndCombosForOutput()
        sap_model.Results.Setup.SetCaseSelectedForOutput('LIVE')

        # 获取梁跨中位移
        # (结果提取代码...)

        results.append({
            'width': width,
            'height': height,
            'load': load,
            'max_displacement': 0.0  # 实际值从结果中提取
        })

    # 断开连接
    disconnect_from_sap2000(sap_object, sap_model)

    return results
```

## 数据库表访问

SAP2000 还提供了交互式数据库表功能，可以批量导入导出数据：

```python
# 获取数据库表
# 需要使用 DatabaseTables 类
db_tables = sap_model.DatabaseTables

# 导出框架数据到文件
file_path = r'C:\Temp\frame_data.txt'
ret = db_tables.ExportToAccessFile(file_path, 'Frame Object 01 - General')

# 从文件导入数据
ret = db_tables.ImportFromAccessFile(file_path, 'Frame Object 01 - General')
```

## 完整工作流程示例

### 建筑结构分析完整流程

```python
import os
import comtypes.client
import sys

def complete_building_analysis():
    """完整的建筑结构分析示例"""

    # 1. 连接到 SAP2000
    print("连接到 SAP2000...")
    helper = comtypes.client.CreateObject('SAP2000v1.Helper')
    helper = helper.QueryInterface(comtypes.gen.SAP2000v1.cHelper)
    sap_object = helper.CreateObjectProgID("CSI.SAP2000.API.SapObject")
    sap_object.ApplicationStart()
    sap_model = sap_object.SapModel

    # 2. 初始化模型
    print("初始化模型...")
    sap_model.InitializeNewModel()
    sap_model.File.NewBlank()

    # 3. 设置单位 (kN, m, C)
    sap_model.SetPresentUnits(7)

    # 4. 定义材料
    print("定义材料...")
    sap_model.PropMaterial.SetMaterial('C30', 2)  # 混凝土
    sap_model.PropMaterial.SetMPIsotropic('C30', 30000, 0.2, 1e-5)

    sap_model.PropMaterial.SetMaterial('Q345', 1)  # 钢材
    sap_model.PropMaterial.SetMPIsotropic('Q345', 206000, 0.3, 1.2e-5)

    # 5. 定义截面
    print("定义截面...")
    sap_model.PropFrame.SetRectangle('COL400x400', 'C30', 0.4, 0.4)
    sap_model.PropFrame.SetRectangle('BEAM300x600', 'C30', 0.3, 0.6)
    sap_model.PropFrame.SetISection('I1', 'Q345', 0.5, 0.2, 0.01, 0.008, 0.2, 0.01)

    # 6. 创建几何模型
    print("创建几何模型...")

    # 创建节点（单层框架）
    points = {}
    coords = [
        (0, 0, 0), '1',
        (6, 0, 0), '2',
        (12, 0, 0), '3',
        (0, 0, 4.5), '4',
        (6, 0, 4.5), '5',
        (12, 0, 4.5), '6'
    ]

    for i in range(0, len(coords), 2):
        x, y, z = coords[i]
        name, _ = sap_model.PointObj.AddCartesian(x, y, z, '')
        points[coords[i+1]] = name

    # 创建框架
    frames = []
    # 柱
    for i in ['1', '2', '3']:
        frame, _ = sap_model.FrameObj.AddByPoint(
            points[i], points[str(int(i)+3)], '', 'COL400x400', 'Global'
        )
        frames.append(frame)

    # 梁
    for i in range(2):
        frame, _ = sap_model.FrameObj.AddByPoint(
            points[str(4+i)], points[str(5+i)], '', 'BEAM300x600', 'Global'
        )
        frames.append(frame)

    # 7. 施加边界条件
    print("施加边界条件...")
    restraint = [True, True, True, True, True, True]
    for i in ['1', '2', '3']:
        sap_model.PointObj.SetRestraint(points[i], restraint)

    # 8. 施加荷载
    print("施加荷载...")

    # 恒载 (自重)
    sap_model.LoadPatterns.Add('DEAD', 1, 1, True)

    # 活载
    sap_model.LoadPatterns.Add('LIVE', 2, 0, True)
    for frame in frames[3:]:  # 梁
        sap_model.FrameObj.SetLoadDistributed(frame, 'LIVE', 1, 3, 0, 1, 10, 10, 'Local')

    # 风荷载
    sap_model.LoadPatterns.Add('WIND', 4, 0, True)
    sap_model.PointObj.SetLoadForce(points['4'], 'WIND', [2, 0, 0, 0, 0, 0])
    sap_model.PointObj.SetLoadForce(points['5'], 'WIND', [4, 0, 0, 0, 0, 0])
    sap_model.PointObj.SetLoadForce(points['6'], 'WIND', [2, 0, 0, 0, 0, 0])

    # 9. 保存模型
    model_path = r'C:\Models\BuildingFrame.sdb'
    print(f"保存模型: {model_path}")
    sap_model.File.Save(model_path)

    # 10. 运行分析
    print("运行分析...")
    ret = sap_model.Analyze.RunAnalysis()
    if ret == 0:
        print("分析成功完成！")
    else:
        print(f"分析失败，错误代码: {ret}")
        sap_object.ApplicationExit(False)
        sap_model = None
        sap_object = None
        return

    # 11. 提取结果
    print("提取结果...")

    # 选择输出工况
    sap_model.Results.Setup.DeselectAllCasesAndCombosForOutput()
    sap_model.Results.Setup.SetCaseSelectedForOutput('DEAD')
    sap_model.Results.Setup.SetCaseSelectedForOutput('LIVE')
    sap_model.Results.Setup.SetCaseSelectedForOutput('WIND')

    # 获取节点位移
    for point_name in [points['4'], points['5'], points['6']]:
        [n, Obj, Elm, ACase, StepType, StepNum,
         U1, U2, U3, R1, R2, R3, ret] = \
            sap_model.Results.JointDispl(point_name, 0, 0, [], [], [], [], [],
                                        [], [], [], [], [])

        if n > 0:
            print(f"\n节点 {point_name} 位移:")
            for i in range(n):
                print(f"  工况 {ACase[i]}: U3 = {U3[i]:.6f} m")

    # 12. 退出
    print("\n断开连接...")
    sap_object.ApplicationExit(False)
    sap_model = None
    sap_object = None

    print("分析完成！")

if __name__ == "__main__":
    complete_building_analysis()
```

## 常见错误和调试

### 常见错误

1. **连接失败**
   ```
   错误: 无法启动 SAP2000
   解决: 检查 SAP2000 是否已安装，路径是否正确
   ```

2. **模型已锁定**
   ```
   错误: 无法修改已锁定的模型
   解决: 分析完成后需要解锁才能修改
   sap_model.SetModelIsLocked(False)
   ```

3. **对象不存在**
   ```
   错误: 指定的点/框架不存在
   解决: 确保对象名称正确，使用创建时返回的名称
   ```

4. **单位混淆**
   ```
   错误: 结果数值异常
   解决: 检查单位系统，确保输入值与当前单位一致
   ```

### 调试技巧

```python
# 检查返回值
ret = sap_model.SomeFunction()
if ret != 0:
    print(f"函数调用失败，错误代码: {ret}")

# 获取对象列表
[n_points, ret] = sap_model.PointObj.Count()
print(f"模型中有 {n_points} 个节点")

[n_frames, ret] = sap_model.FrameObj.Count()
print(f"模型中有 {n_frames} 个框架对象")

# 遍历所有对象
for i in range(1, n_frames + 1):
    name, ret = sap_model.FrameObj.GetName(i)
    print(f"框架 {i}: {name}")
```

## 最佳实践

### 1. 错误处理

```python
def safe_api_call(func, *args, **kwargs):
    """
    安全的 API 调用包装器
    """
    try:
        ret = func(*args, **kwargs)
        if ret != 0 and ret is not None:
            print(f"警告: 函数 {func.__name__} 返回错误代码 {ret}")
        return ret
    except Exception as e:
        print(f"错误: {e}")
        return None
```

### 2. 资源管理

```python
# 使用 try-finally 确保资源释放
try:
    sap_object, sap_model = connect_to_sap2000()
    # 执行操作
    ...
finally:
    disconnect_from_sap2000(sap_object, sap_model)
```

### 3. 单位一致性

```python
# 始终明确设置单位
sap_model.SetPresentUnits(7)  # kN_m_C

# 在注释中注明单位
# 弹性模量: 30000 MPa (在 kN_m_C 单位下为 30000000 kN/m²)
modulus = 30000000
sap_model.PropMaterial.SetMPIsotropic('C30', modulus, 0.2, 1e-5)
```

### 4. 模块化设计

```python
class SAP2000Model:
    """SAP2000 模型封装类"""

    def __init__(self):
        self.sap_object = None
        self.sap_model = None

    def connect(self):
        """连接到 SAP2000"""
        self.sap_object, self.sap_model = connect_to_sap2000()

    def new_model(self):
        """创建新模型"""
        self.sap_model.InitializeNewModel()
        self.sap_model.File.NewBlank()

    def add_material(self, name, mtype, modulus, poisson, alpha):
        """添加材料"""
        self.sap_model.PropMaterial.SetMaterial(name, mtype)
        self.sap_model.PropMaterial.SetMPIsotropic(name, modulus, poisson, alpha)

    # ... 更多方法

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        disconnect_from_sap2000(self.sap_object, self.sap_model)

# 使用上下文管理器
with SAP2000Model() as model:
    model.new_model()
    model.add_material('CONC', 2, 30000, 0.2, 1e-5)
    # ...
```

## 快速参考

### 常用函数速查表

| 功能 | 函数 | 示例 |
|------|------|------|
| 连接SAP2000 | `helper.CreateObject()` | 见连接示例 |
| 新建模型 | `InitializeNewModel()` | `ret = sap_model.InitializeNewModel()` |
| 打开文件 | `File.OpenFile()` | `ret = sap_model.File.OpenFile(path)` |
| 保存文件 | `File.Save()` | `ret = sap_model.File.Save(path)` |
| 设置单位 | `SetPresentUnits()` | `ret = sap_model.SetPresentUnits(7)` |
| 添加材料 | `PropMaterial.SetMaterial()` | `ret = sap_model.PropMaterial.SetMaterial('CONC', 2)` |
| 框架截面 | `PropFrame.SetRectangle()` | `ret = sap_model.PropFrame.SetRectangle('R1', 'CONC', 0.4, 0.4)` |
| 添加节点 | `PointObj.AddCartesian()` | `name, ret = sap_model.PointObj.AddCartesian(x, y, z, '')` |
| 添加框架 | `FrameObj.AddByCoord()` | `name, ret = sap_model.FrameObj.AddByCoord(...)` |
| 设置约束 | `PointObj.SetRestraint()` | `ret = sap_model.PointObj.SetRestraint('P1', [T,T,T,T,T,T])` |
| 添加荷载模式 | `LoadPatterns.Add()` | `ret = sap_model.LoadPatterns.Add('LIVE', 2, 0, True)` |
| 点荷载 | `PointObj.SetLoadForce()` | `ret = sap_model.PointObj.SetLoadForce('P1', 'LIVE', [0,0,-10,0,0,0])` |
| 分布荷载 | `FrameObj.SetLoadDistributed()` | `ret = sap_model.FrameObj.SetLoadDistributed(...)` |
| 运行分析 | `Analyze.RunAnalysis()` | `ret = sap_model.Analyze.RunAnalysis()` |
| 节点位移 | `Results.JointDispl()` | `[n, ...] = sap_model.Results.JointDispl(...)` |
| 框架内力 | `Results.FrameForce()` | `[n, ...] = sap_model.Results.FrameForce(...)` |
| 退出程序 | `ApplicationExit()` | `ret = sap_object.ApplicationExit(False)` |

### 单位代码

```python
# 常用单位代码
3  = kip, in, F
4  = kip, ft, F
6  = kN, mm, C
7  = kN, m, C     # 建筑结构常用
9  = kgf, mm, C
10 = kgf, m, C
11 = N, mm, C
12 = N, m, C
```

### 材料类型

```python
1 = 钢材 (STEEL)
2 = 混凝土 (CONCRETE)
3 = 无 (NONE)
4 = 铝 (ALUMINUM)
5 = 冷弯型钢 (COLD_FORMED)
6 = 钢筋 (REBAR)
7 = 预应力筋 (TENDON)
```

### 荷载类型

```python
1 = 恒载 (DEAD)
2 = 活载 (LIVE)
3 = 地震 (QUAKE)
4 = 风荷载 (WIND)
5 = 雪荷载 (SNOW)
8 = 其他 (OTHER)
```

## 进阶主题

### 组功能

```python
# 创建组
ret = sap_model.Group.Add('ALL_BEAMS')

# 添加对象到组
ret = sap_model.Group.SetGroupAssign('Frame1', 'ALL_BEAMS')

# 选择组中的所有对象
ret = sap_model.SelectObj.Group('ALL_BEAMS')
```

### 视图控制

```python
# 刷新视图
ret = sap_model.View.RefreshView(0, False)

# 缩放视图到适合
ret = sap_model.View.ZoomView()
```

### 选择功能

```python
# 全部清除选择
ret = sap_model.SelectObj.ClearSelection()

# 选择所有框架对象
ret = sap_model.SelectObj.All('Frame')

# 按属性选择
ret = sap_model.SelectObj.Property('Frame', 'COL400x400')
```

## 与其他软件集成

### Excel 集成 (使用 openpyxl)

```python
import openpyxl

def export_results_to_excel(results, excel_path):
    """将结果导出到 Excel"""
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "分析结果"

    # 写入标题
    ws['A1'] = '节点'
    ws['B1'] = '工况'
    ws['C1'] = 'U3 (m)'

    # 写入数据
    row = 2
    for node, cases in results.items():
        for case, disp in cases.items():
            ws[f'A{row}'] = node
            ws[f'B{row}'] = case
            ws[f'C{row}'] = disp
            row += 1

    wb.save(excel_path)
```

## 学习资源

- **API 文档路径**: 本地 SAP2000 安装目录下的 API 文档
- **示例代码**: 参考 Example_Code 目录下的完整示例
- **函数参考**: SAP2000_API_Functions 目录包含所有函数的详细说明

## 技巧提示

1. **始终检查返回值**：大多数 API 函数返回状态码，0 表示成功
2. **使用有意义的名称**：不要依赖自动生成的名称，使用描述性名称
3. **保存中间结果**：在关键步骤后保存模型
4. **记录日志**：记录关键操作以便调试
5. **单元测试**：对关键函数编写测试用例
6. **版本兼容性**：注意不同版本 SAP2000 的 API 差异

---

现在你可以使用此 skill 来完成各种 SAP2000 自动化任务。当你需要：
- 创建或修改 SAP2000 模型
- 自动化结构分析流程
- 提取和处理分析结果
- 进行参数化研究
- 批量处理多个模型

请告诉 Claude 你的具体需求，它将根据此 skill 提供详细的指导和代码示例。
