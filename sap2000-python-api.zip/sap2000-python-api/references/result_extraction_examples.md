# SAP2000 结果提取实用示例

## 常见需求的结果提取

### 1. 提取所有节点的最大位移

```python
def get_all_node_displacements(sap_model, load_case='LIVE'):
    """
    提取所有节点在指定工况下的位移

    参数:
        sap_model: SapModel 对象
        load_case: 荷载工况名称

    返回:
        字典: {节点名: {u1, u2, u3, r1, r2, r3}}
    """
    # 选择输出工况
    sap_model.Results.Setup.DeselectAllCasesAndCombosForOutput()
    sap_model.Results.Setup.SetCaseSelectedForOutput(load_case)

    # 获取节点数量
    [n_points, ret] = sap_model.PointObj.Count()

    displacements = {}

    for i in range(1, n_points + 1):
        # 获取节点名称
        [point_name, ret] = sap_model.PointObj.GetName(i)

        # 初始化变量
        NumberResults = 0
        Obj = []
        Elm = []
        ACase = []
        StepType = []
        StepNum = []
        U1 = []
        U2 = []
        U3 = []
        R1 = []
        R2 = []
        R3 = []

        # 提取位移
        [NumberResults, Obj, Elm, ACase, StepType, StepNum,
         U1, U2, U3, R1, R2, R3, ret] = \
            sap_model.Results.JointDispl(
                point_name, 0,
                NumberResults, Obj, Elm, ACase, StepType, StepNum,
                U1, U2, U3, R1, R2, R3
            )

        if NumberResults > 0:
            # 保存最后一个结果（通常是目标工况）
            displacements[point_name] = {
                'U1': U1[-1],  # X 向位移 (m)
                'U2': U2[-1],  # Y 向位移 (m)
                'U3': U3[-1],  # Z 向位移 (m) - 通常最重要
                'R1': R1[-1],  # 绕 X 轴转角 (rad)
                'R2': R2[-1],  # 绕 Y 轴转角 (rad)
                'R3': R3[-1],  # 绕 Z 轴转角 (rad)
            }

    return displacements

# 使用示例
disps = get_all_node_displacements(SapModel, 'LIVE')

# 找出最大竖向位移
max_disp = 0
max_point = ''
for point, data in disps.items():
    if abs(data['U3']) > abs(max_disp):
        max_disp = data['U3']
        max_point = point

print(f"最大竖向位移: 节点 {max_point}, {max_disp*1000:.2f} mm")
```

### 2. 提取所有梁的控制内力

```python
def get_all_frame_forces(sap_model, load_case='LIVE'):
    """
    提取所有框架对象在指定工况下的控制内力

    返回:
        字典: {框架名: {max_moment, min_moment, max_shear, max_axial, locations}}
    """
    # 选择输出工况
    sap_model.Results.Setup.DeselectAllCasesAndCombosForOutput()
    sap_model.Results.Setup.SetCaseSelectedForOutput(load_case)

    # 获取框架数量
    [n_frames, ret] = sap_model.FrameObj.Count()

    frame_forces = {}

    for i in range(1, n_frames + 1):
        # 获取框架名称
        [frame_name, ret] = sap_model.FrameObj.GetName(i)

        # 初始化变量
        NumberResults = 0
        Obj = []
        Elm = []
        ACase = []
        StepType = []
        StepNum = []
        Loc = []
        P = []
        V2 = []
        V3 = []
        T = []
        M2 = []
        M3 = []

        # 提取内力
        [NumberResults, Obj, Elm, ACase, StepType, StepNum,
         Loc, P, V2, V3, T, M2, M3, ret] = \
            sap_model.Results.FrameForce(
                frame_name, 0,
                NumberResults, Obj, Elm, ACase, StepType, StepNum,
                Loc, P, V2, V3, T, M2, M3
            )

        if NumberResults > 0:
            # 找到控制内力值
            max_m3 = max(M3)
            min_m3 = min(M3)
            max_m3_loc = Loc[M3.index(max_m3)]
            min_m3_loc = Loc[M3.index(min_m3)]

            max_v3 = max([abs(v) for v in V3])
            max_v3_loc = Loc[V3.index(max_v3) if max_v3 in V3 else V3.index(-max_v3)]

            max_p = max([abs(p) for p in P])

            frame_forces[frame_name] = {
                'max_moment': max_m3,        # 最大正弯矩 (kN·m)
                'max_moment_loc': max_m3_loc,  # 位置 (相对距离)
                'min_moment': min_m3,        # 最大负弯矩 (kN·m)
                'min_moment_loc': min_m3_loc,
                'max_shear': max_v3,         # 最大剪力 (kN)
                'max_shear_loc': max_v3_loc,
                'max_axial': max_p,          # 最大轴力 (kN)
            }

    return frame_forces

# 使用示例
forces = get_all_frame_forces(SapModel, 'LIVE')

# 找出最危险的梁
print("\n梁内力汇总:")
print("=" * 70)
for frame, data in forces.items():
    print(f"\n{frame}:")
    print(f"  最大正弯矩: {data['max_moment']:.2f} kN·m (位置: {data['max_moment_loc']:.2%})")
    print(f"  最大负弯矩: {data['min_moment']:.2f} kN·m (位置: {data['min_moment_loc']:.2%})")
    print(f"  最大剪力: {data['max_shear']:.2f} kN (位置: {data['max_shear_loc']:.2%})")
    print(f"  最大轴力: {data['max_axial']:.2f} kN")

# 找出弯矩最大的梁
max_moment_frame = max(forces.items(),
                       key=lambda x: x[1]['max_moment'])
print(f"\n最大正弯矩出现在 {max_moment_frame[0]}: "
      f"{max_moment_frame[1]['max_moment']:.2f} kN·m")
```

### 3. 提取多个工况的结果

```python
def get_multiple_load_case_results(sap_model, frame_names, load_cases):
    """
    提取多个工况下的结果

    参数:
        sap_model: SapModel 对象
        frame_names: 框架名称列表
        load_cases: 荷载工况列表

    返回:
        字典: {框架名: {工况名: {内力数据}}}
    """
    results = {}

    for frame_name in frame_names:
        results[frame_name] = {}

        for load_case in load_cases:
            # 选择当前工况
            sap_model.Results.Setup.DeselectAllCasesAndCombosForOutput()
            sap_model.Results.Setup.SetCaseSelectedForOutput(load_case)

            # 提取内力
            NumberResults = 0
            Obj = []
            Elm = []
            ACase = []
            StepType = []
            StepNum = []
            Loc = []
            P = []
            V2 = []
            V3 = []
            T = []
            M2 = []
            M3 = []

            [NumberResults, Obj, Elm, ACase, StepType, StepNum,
             Loc, P, V2, V3, T, M2, M3, ret] = \
                sap_model.Results.FrameForce(
                    frame_name, 0,
                    NumberResults, Obj, Elm, ACase, StepType, StepNum,
                    Loc, P, V2, V3, T, M2, M3
                )

            if NumberResults > 0:
                results[frame_name][load_case] = {
                    'max_m3': max(M3),
                    'min_m3': min(M3),
                    'max_v3': max([abs(v) for v in V3]),
                    'max_p': max([abs(p) for p in P])
                }

    return results

# 使用示例
frames_to_check = ['Frame1', 'Frame2', 'Frame3']
cases_to_check = ['DEAD', 'LIVE', 'WIND']

multi_results = get_multiple_load_case_results(
    SapModel, frames_to_check, cases_to_check
)

# 打印对比表
print(f"{'框架':<10} {'工况':<10} {'最大弯矩':<15} {'最小弯矩':<15} {'最大剪力':<15}")
print("-" * 70)
for frame in frames_to_check:
    for case in cases_to_check:
        data = multi_results[frame][case]
        print(f"{frame:<10} {case:<10} "
              f"{data['max_m3']:>10.2f}    "
              f"{data['min_m3']:>10.2f}    "
              f"{data['max_v3']:>10.2f}")
```

### 4. 提取并导出到 Excel

```python
import openpyxl
from openpyxl.styles import Font, Alignment

def export_results_to_excel(sap_model, file_path, load_case='LIVE'):
    """
    提取结果并导出到 Excel 文件

    参数:
        sap_model: SapModel 对象
        file_path: Excel 文件路径
        load_case: 荷载工况名称
    """

    # 创建工作簿
    wb = openpyxl.Workbook()

    # ========== 工作表 1: 节点位移 ==========
    ws1 = wb.active
    ws1.title = "节点位移"

    # 标题行
    headers = ['节点', 'U1 (m)', 'U2 (m)', 'U3 (m)', 'U3 (mm)']
    ws1.append(headers)

    # 设置标题样式
    for cell in ws1[1]:
        cell.font = Font(bold=True)
        cell.alignment = Alignment(horizontal='center')

    # 提取位移
    sap_model.Results.Setup.DeselectAllCasesAndCombosForOutput()
    sap_model.Results.Setup.SetCaseSelectedForOutput(load_case)

    [n_points, ret] = sap_model.PointObj.Count()

    for i in range(1, n_points + 1):
        [point_name, ret] = sap_model.PointObj.GetName(i)

        NumberResults = 0
        Obj, Elm, ACase, StepType, StepNum = [], [], [], [], []
        U1, U2, U3, R1, R2, R3 = [], [], [], [], [], []

        [NumberResults, Obj, Elm, ACase, StepType, StepNum,
         U1, U2, U3, R1, R2, R3, ret] = \
            sap_model.Results.JointDispl(
                point_name, 0,
                NumberResults, Obj, Elm, ACase, StepType, StepNum,
                U1, U2, U3, R1, R2, R3
            )

        if NumberResults > 0:
            ws1.append([
                point_name,
                f"{U1[-1]:.6f}",
                f"{U2[-1]:.6f}",
                f"{U3[-1]:.6f}",
                f"{U3[-1]*1000:.3f}"
            ])

    # ========== 工作表 2: 梁内力 ==========
    ws2 = wb.create_sheet("梁内力")

    # 标题行
    headers = ['框架', '最大弯矩\n(kN·m)', '最小弯矩\n(kN·m)',
               '最大剪力\n(kN)', '最大轴力\n(kN)']
    ws2.append(headers)

    # 设置标题样式
    for cell in ws2[1]:
        cell.font = Font(bold=True)
        cell.alignment = Alignment(horizontal='center')

    # 提取内力
    [n_frames, ret] = sap_model.FrameObj.Count()

    for i in range(1, n_frames + 1):
        [frame_name, ret] = sap_model.FrameObj.GetName(i)

        NumberResults = 0
        Obj, Elm, ACase, StepType, StepNum = [], [], [], [], []
        Loc, P, V2, V3, T, M2, M3 = [], [], [], [], [], [], []

        [NumberResults, Obj, Elm, ACase, StepType, StepNum,
         Loc, P, V2, V3, T, M2, M3, ret] = \
            sap_model.Results.FrameForce(
                frame_name, 0,
                NumberResults, Obj, Elm, ACase, StepType, StepNum,
                Loc, P, V2, V3, T, M2, M3
            )

        if NumberResults > 0:
            max_m3 = max(M3)
            min_m3 = min(M3)
            max_v3 = max([abs(v) for v in V3])
            max_p = max([abs(p) for p in P])

            ws2.append([
                frame_name,
                f"{max_m3:.2f}",
                f"{min_m3:.2f}",
                f"{max_v3:.2f}",
                f"{max_p:.2f}"
            ])

    # 调整列宽
    for ws in [ws1, ws2]:
        for column in ws.columns:
            max_length = 0
            column_letter = column[0].column_letter
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(str(cell.value))
                except:
                    pass
            adjusted_width = min(max_length + 2, 50)
            ws.column_dimensions[column_letter].width = adjusted_width

    # 保存文件
    wb.save(file_path)
    print(f"✓ 结果已导出到: {file_path}")

# 使用示例
export_results_to_excel(
    SapModel,
    r'C:\Temp\Analysis_Results.xlsx',
    'LIVE'
)
```

### 5. 提取最不利位置

```python
def find_critical_locations(sap_model, load_case='LIVE'):
    """
    找出最不利的位置

    返回:
        字典: {
            'max_displacement': {'node': 节点名, 'value': 位移值},
            'max_moment': {'frame': 框架名, 'value': 弯矩值, 'location': 位置},
            'max_shear': {'frame': 框架名, 'value': 剪力值, 'location': 位置}
        }
    """
    sap_model.Results.Setup.DeselectAllCasesAndCombosForOutput()
    sap_model.Results.Setup.SetCaseSelectedForOutput(load_case)

    critical = {}

    # ========== 1. 最大节点位移 ==========
    [n_points, ret] = sap_model.PointObj.Count()
    max_disp = 0
    max_disp_node = ''

    for i in range(1, n_points + 1):
        [point_name, ret] = sap_model.PointObj.GetName(i)

        NumberResults = 0
        Obj, Elm, ACase, StepType, StepNum = [], [], [], [], []
        U1, U2, U3, R1, R2, R3 = [], [], [], [], [], []

        [NumberResults, Obj, Elm, ACase, StepType, StepNum,
         U1, U2, U3, R1, R2, R3, ret] = \
            sap_model.Results.JointDispl(
                point_name, 0,
                NumberResults, Obj, Elm, ACase, StepType, StepNum,
                U1, U2, U3, R1, R2, R3
            )

        if NumberResults > 0:
            disp = abs(U3[-1])  # 竖向位移
            if disp > max_disp:
                max_disp = disp
                max_disp_node = point_name

    critical['max_displacement'] = {
        'node': max_disp_node,
        'value': max_disp,
        'value_mm': max_disp * 1000
    }

    # ========== 2. 最大弯矩 ==========
    [n_frames, ret] = sap_model.FrameObj.Count()
    max_moment = 0
    max_moment_frame = ''
    max_moment_loc = 0

    for i in range(1, n_frames + 1):
        [frame_name, ret] = sap_model.FrameObj.GetName(i)

        NumberResults = 0
        Obj, Elm, ACase, StepType, StepNum = [], [], [], [], []
        Loc, P, V2, V3, T, M2, M3 = [], [], [], [], [], [], []

        [NumberResults, Obj, Elm, ACase, StepType, StepNum,
         Loc, P, V2, V3, T, M2, M3, ret] = \
            sap_model.Results.FrameForce(
                frame_name, 0,
                NumberResults, Obj, Elm, ACase, StepType, StepNum,
                Loc, P, V2, V3, T, M2, M3
            )

        if NumberResults > 0:
            for j, m in enumerate(M3):
                if abs(m) > abs(max_moment):
                    max_moment = m
                    max_moment_frame = frame_name
                    max_moment_loc = Loc[j]

    critical['max_moment'] = {
        'frame': max_moment_frame,
        'value': max_moment,
        'location': max_moment_loc
    }

    # ========== 3. 最大剪力 ==========
    max_shear = 0
    max_shear_frame = ''
    max_shear_loc = 0

    for i in range(1, n_frames + 1):
        [frame_name, ret] = sap_model.FrameObj.GetName(i)

        NumberResults = 0
        Obj, Elm, ACase, StepType, StepNum = [], [], [], [], []
        Loc, P, V2, V3, T, M2, M3 = [], [], [], [], [], [], []

        [NumberResults, Obj, Elm, ACase, StepType, StepNum,
         Loc, P, V2, V3, T, M2, M3, ret] = \
            sap_model.Results.FrameForce(
                frame_name, 0,
                NumberResults, Obj, Elm, ACase, StepType, StepNum,
                Loc, P, V2, V3, T, M2, M3
            )

        if NumberResults > 0:
            for j, v in enumerate(V3):
                if abs(v) > abs(max_shear):
                    max_shear = v
                    max_shear_frame = frame_name
                    max_shear_loc = Loc[j]

    critical['max_shear'] = {
        'frame': max_shear_frame,
        'value': max_shear,
        'location': max_shear_loc
    }

    return critical

# 使用示例
critical = find_critical_locations(SapModel, 'LIVE')

print("\n最不利位置汇总:")
print("=" * 60)
print(f"最大竖向位移:")
print(f"  节点: {critical['max_displacement']['node']}")
print(f"  数值: {critical['max_displacement']['value_mm']:.2f} mm")

print(f"\n最大弯矩:")
print(f"  框架: {critical['max_moment']['frame']}")
print(f"  数值: {critical['max_moment']['value']:.2f} kN·m")
print(f"  位置: {critical['max_moment']['location']:.2%}")

print(f"\n最大剪力:")
print(f"  框架: {critical['max_shear']['frame']}")
print(f"  数值: {critical['max_shear']['value']:.2f} kN")
print(f"  位置: {critical['max_shear']['location']:.2%}")
```

## 提示和技巧

### 1. 始终选择正确的输出工况

```python
# 清除所有选择
sap_model.Results.Setup.DeselectAllCasesAndCombosForOutput()

# 选择需要的工况
sap_model.Results.Setup.SetCaseSelectedForOutput('DEAD')
sap_model.Results.Setup.SetCaseSelectedForOutput('LIVE')
```

### 2. 检查结果数量

```python
if NumberResults > 0:
    # 处理结果
    ...
else:
    print(f"警告: {frame_name} 在工况 {load_case} 下没有结果")
```

### 3. 单位转换显示

```python
# 内部计算使用基本单位 (kN, m)
disp_m = U3[-1]

# 显示时转换为更直观的单位
disp_mm = disp_m * 1000  # mm
print(f"位移: {disp_mm:.2f} mm")
```

### 4. 处理错误返回值

```python
ret = sap_model.Results.JointDispl(...)
if ret != 0:
    print(f"错误: 提取位移失败，错误代码 {ret}")
    # 进行错误处理
```

---

**总结**: 这些示例涵盖了最常见的 SAP2000 结果提取需求，可以根据具体项目进行调整使用！
