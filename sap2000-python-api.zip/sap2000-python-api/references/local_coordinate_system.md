# SAP2000 局部坐标系说明

## 框架对象（梁/柱）的局部坐标系

### 坐标系定义

```
        Local 3 (2轴方向，通常竖向)
             ↑
             |
             |
             |______→ Local 1 (轴向)
            /
           /
         ↙
    Local 2 (1-2平面外方向)
```

### 三个坐标轴

| 轴 | 名称 | 方向说明 | 用途 |
|----|------|---------|------|
| **Local 1** | 轴向 | 沿梁/柱的长度方向 | 轴力、轴向变形 |
| **Local 2** | 侧向 | 垂直于构件轴线，在 1-2 平面内 | 剪力 V2、弯矩 M2（弱轴） |
| **Local 3** | 横向 | 垂直于 1-2 平面 | 剪力 V3、弯矩 M3（强轴） |

### 典型构件的方向

#### 水平梁（沿 X 轴）

```
         Y (Global)
         ↑
         |  Local 3 ↑
         |          |
   _______|__________|_________→ X (Global)
   点1    点2          |
         Local 2 ↗     (Local 1 沿 X 方向)
```

**对于水平梁**:
- **Local 1**: 沿梁长度方向（水平）
- **Local 2**: 垂直于梁，在水平面内（通常不重要）
- **Local 3**: 竖向向上 ⬆️（重力荷载方向）

**施加竖向荷载**:
```python
# 使用 Local 3 方向（方向代码 = 3）
ret = SapModel.FrameObj.SetLoadDistributed(
    frame_name, 'LIVE',
    1,           # 荷载类型: 1=力
    3,           # 方向: 3=Local3 (竖向)
    0, 1,        # 相对位置
    load, load,  # 荷载值
    'Local'
)
```

#### 竖向柱（沿 Z 轴）

```
         Z (Global)
         ↑
         |  Local 1 (沿柱高度)
         |
         |
         |______→ Y (Global)
        /  Local 2
       /   (通常沿全局 X 或 Y)
  Local 3 ↖
```

**对于竖向柱**:
- **Local 1**: 沿柱高度方向（竖向）
- **Local 2**: 水平方向（通常沿全局 X 轴）
- **Local 3**: 水平方向（通常沿全局 Y 轴）

## 内力分量的对应关系

### 结果提取中的内力

```python
[NumberResults, Obj, Elm, ACase, StepType, StepNum,
 Loc, P, V2, V3, T, M2, M3, ret] = \
    SapModel.Results.FrameForce(frame_name, 0, ...)
```

**内力分量说明**:

| 符号 | 名称 | 物理意义 | 典型关注值 |
|------|------|---------|-----------|
| **P** | 轴力 | 沿 Local 1 的力 | 柱轴力、拉压力 |
| **V2** | 剪力 | Local 2 方向的剪力 | 弱轴剪力 |
| **V3** | 剪力 | Local 3 方向的剪力 | 强轴剪力（重要！） |
| **T** | 扭矩 | 绕 Local 1 的扭矩 | 抗扭设计 |
| **M2** | 弯矩 | 绕 Local 2 的弯矩 | 弱轴弯矩 |
| **M3** | 弯矩 | 绕 Local 3 的弯矩 | 强轴弯矩（重要！） |

### 梁的内力

**对于水平梁**:
- **P**: 通常很小（轴向力）
- **V3**: 主要剪力（竖向剪力）⭐
- **M3**: 主要弯矩（竖向荷载产生的弯矩）⭐
- **V2, M2**: 通常很小（除非有横向荷载）

```python
# 提取梁的主要内力
max_moment = max(M3)  # 最大竖向弯矩
max_shear = max([abs(v) for v in V3])  # 最大竖向剪力
```

### 柱的内力

**对于竖向柱**:
- **P**: 主要内力（轴向压力/拉力）⭐
- **V2, V3**: 两个方向的剪力（地震/风荷载）⭐
- **M2, M3**: 两个方向的弯矩（地震/风荷载）⭐
- **T**: 通常较小（除非有扭矩）

```python
# 提取柱的主要内力
axial_force = max([abs(p) for p in P])  # 最大轴力
max_moment = max(max([abs(m) for m in M2]),
                 max([abs(m) for m in M3]))  # 最大弯矩
```

## 荷载方向代码

### SetLoadDistributed 的方向参数

```python
ret = SapModel.FrameObj.SetLoadDistributed(
    frame_name, load_pattern,
    1,        # 荷载类型: 1=力, 2=弯矩
    Direction,  # 方向参数 ⬅️ 这很重要！
    0, 1,     # 相对位置
    val1, val2,
    'Local'
)
```

**方向代码**:

| 代码 | 方向 | 适用场景 |
|------|------|---------|
| 1 | Local 1 | 轴向荷载（温度、预应力） |
| 2 | Local 2 | 侧向荷载（罕见） |
| **3** | **Local 3** | **竖向荷载（重力、活载）** ⭐ |
| 11 | Global X | 水平地震、风荷载 |
| 12 | Global Y | 水平地震、风荷载 |
| 13 | Global Z | 竖向荷载（另一种方式） |

### 梁的荷载施加示例

#### 竖向均布荷载（最常见）

```python
# 方式 1: 使用 Local 3（推荐）
ret = SapModel.FrameObj.SetLoadDistributed(
    frame, 'LIVE',
    1,          # 力
    3,          # Local 3 (竖向)
    0, 1,       # 全跨
    20, 20,     # 20 kN/m
    'Local'
)

# 方式 2: 使用 Global Z（效果相同）
ret = SapModel.FrameObj.SetLoadDistributed(
    frame, 'LIVE',
    1,          # 力
    13,         # Global Z (竖向)
    0, 1,
    20, 20,
    'Global'    # 注意坐标系
)
```

#### 水平荷载（地震/风）

```python
# 使用 Global 方向更直观
ret = SapModel.FrameObj.SetLoadDistributed(
    frame, 'WIND',
    1,          # 力
    11,         # Global X
    0, 1,
    5, 5,       # 5 kN/m
    'Global'    # 必须使用 Global
)
```

## 获取局部坐标系

```python
# 获取框架对象的局部坐标系角度
[angle, ret] = SapModel.FrameObj.GetLocalAxes(frame_name)
print(f"局部坐标系角度: {angle} 度")
```

## 修改局部坐标系

```python
# 旋转框架的局部坐标系
# angle: 旋转角度（度）
ret = SapModel.FrameObj.SetLocalAxes(frame_name, angle)
```

**示例**: 对于倾斜的梁，可能需要旋转局部坐标系，使 Local 3 始终保持竖向。

## 常见错误

### ❌ 错误 1: 荷载方向错误

```python
# ❌ 错误：对水平梁使用 Local 1 施加重力荷载
ret = SapModel.FrameObj.SetLoadDistributed(
    frame, 'LIVE', 1, 1, 0, 1, 20, 20, 'Local'
)
# 结果：荷载沿梁轴向，不会产生弯曲！
```

**正确做法**:
```python
# ✅ 正确：使用 Local 3
ret = SapModel.FrameObj.SetLoadDistributed(
    frame, 'LIVE', 1, 3, 0, 1, 20, 20, 'Local'
)
```

### ❌ 错误 2: 内力提取错误

```python
# ❌ 错误：对梁使用 V2 作为主要剪力
max_shear = max([abs(v) for v in V2])  # 错误！
```

**正确做法**:
```python
# ✅ 正确：梁使用 V3
max_shear = max([abs(v) for v in V3])  # 竖向剪力
max_moment = max(M3)                   # 竖向弯矩
```

## 快速参考

### 梁（水平构件）

```python
# 施加荷载
direction = 3  # Local 3 (竖向)

# 提取内力
shear = V3     # 主要剪力
moment = M3    # 主要弯矩
axial = P      # 轴力（通常小）
```

### 柱（竖向构件）

```python
# 施加荷载
direction = 11 or 12  # Global X 或 Y（水平荷载）

# 提取内力
axial = P      # 轴力（最重要）
shear1 = V2    # 一个方向的剪力
shear2 = V3    # 另一个方向的剪力
moment1 = M2   # 一个方向的弯矩
moment2 = M3   # 另一个方向的弯矩
```

---

**总结**:
- 梁：关注 **V3** 和 **M3**（竖向荷载效应）
- 柱：关注 **P**、**V2/V3**、**M2/M3**（全方向）
- 荷载方向：竖向用 **Local 3** 或 **Global Z**，水平用 **Global X/Y**
