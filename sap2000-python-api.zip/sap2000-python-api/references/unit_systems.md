# SAP2000 单位系统详细说明

## 单位系统的重要性

⚠️ **最重要规则**: 所有输入值必须与当前单位系统一致！

SAP2000 不会自动转换单位。如果你设置了单位为 kN-m-C，但输入了 mm 的尺寸，结果会完全错误。

## 常用单位系统代码

### 建筑结构常用单位

```python
# kN, m, C - 建筑结构最常用
kN_m_C = 7
SapModel.SetPresentUnits(kN_m_C)

# N, mm, C - 需要高精度时使用
N_mm_C = 11
SapModel.SetPresentUnits(N_mm_C)

# kgf, m, C - 老规范或特定项目
kgf_m_C = 10
SapModel.SetPresentUnits(kgf_m_C)
```

### 完整单位代码表

| 代码 | 力单位 | 长度单位 | 温度单位 | 适用场景 |
|-----|--------|---------|---------|----------|
| 3   | kip    | in      | F       | 英制（美国） |
| 4   | kip    | ft      | F       | 英制（美国） |
| 6   | kN     | mm      | C       | 需要高精度 |
| **7** | **kN** | **m** | **C** | **建筑结构（推荐）** |
| 9   | kgf    | mm      | C       | 老规范 |
| 10  | kgf    | m       | C       | 老规范 |
| 11  | N      | mm      | C       | 高精度小型结构 |
| 12  | N      | m       | C       | 科学研究 |

## 各单位系统下的典型数值范围

### kN-m-C 系统（代码 7，推荐）

**几何尺寸**:
```python
# 梁截面: 0.3 x 0.5 m (300mm x 500mm)
SapModel.PropFrame.SetRectangle('BEAM', 'C30', 0.3, 0.5)

# 柱截面: 0.4 x 0.4 m (400mm x 400mm)
SapModel.PropFrame.SetRectangle('COL', 'C30', 0.4, 0.4)

# 跨度: 6 m
span = 6.0  # m

# 层高: 3.6 m
height = 3.6  # m
```

**材料属性**:
```python
# 弹性模量: 30000 MPa = 30,000,000 kN/m²
E = 30000000  # kN/m²
SapModel.PropMaterial.SetMPIsotropic('C30', E, 0.2, 1e-5)

# 重度: 25 kN/m³
weight = 25  # kN/m³
```

**荷载**:
```python
# 均布荷载: 20 kN/m
distributed_load = 20  # kN/m
SapModel.FrameObj.SetLoadDistributed(frame, 'LIVE', 1, 3, 0, 1,
                                      distributed_load, distributed_load, 'Local')

# 集中荷载: 50 kN
point_load = [0, 0, -50, 0, 0, 0]  # [F1, F2, F3, M1, M2, M3] kN, kN·m
SapModel.PointObj.SetLoadForce(point, 'LIVE', point_load)
```

**结果**:
```python
# 位移: m (显示时转换为 mm)
displacement_m = -0.0123  # m
displacement_mm = displacement_m * 1000  # -12.3 mm

# 内力: kN 或 kN·m
moment = 125.5  # kN·m
shear = 45.2    # kN
axial = 230.8   # kN
```

### N-mm-C 系统（代码 11，高精度）

**几何尺寸**:
```python
# 梁截面: 300 x 500 mm
SapModel.PropFrame.SetRectangle('BEAM', 'C30', 300, 500)

# 跨度: 6000 mm
span = 6000  # mm
```

**材料属性**:
```python
# 弹性模量: 30000 MPa = 30000 N/mm²
E = 30000  # N/mm²
SapModel.PropMaterial.SetMPIsotropic('C30', E, 0.2, 1e-5)
```

**荷载**:
```python
# 均布荷载: 20 N/mm = 20 kN/m
distributed_load = 20  # N/mm

# 集中荷载: 50000 N = 50 kN
point_load = [0, 0, -50000, 0, 0, 0]  # N
```

## 单位换算

### 长度换算

```python
# m 转 mm
mm = m * 1000

# mm 转 m
m = mm / 1000

# 示例
beam_width_m = 0.3   # m
beam_width_mm = 0.3 * 1000 = 300  # mm
```

### 力换算

```python
# kN 转 N
N = kN * 1000

# N 转 kN
kN = N / 1000

# kgf 转 kN (重力加速度 g = 9.81 m/s²)
kN = kgf * 9.81 / 1000

# 示例
load_kN = 50    # kN
load_N = 50000  # N
```

### 应力/弹性模量换算

```python
# MPa 转 kN/m²
kN_m2 = MPa * 1000

# kN/m² 转 MPa
MPa = kN_m2 / 1000

# 示例
E_MPa = 30000          # MPa
E_kN_m2 = 30000000     # kN/m²
```

### 荷载集度换算

```python
# kN/m 转 N/mm
N_mm = (kN_m * 1000) / 1000 = kN_m  # 数值相同！

# 但要注意单位是 N/mm 而不是 kN/m
# 示例：20 kN/m = 20 N/mm (数值相同，单位不同)

# 面荷载换算
# kN/m² 转 N/mm²
N_mm2 = kN_m2 * 0.001

# 示例：2 kN/m² = 0.002 N/mm²
```

## 常见单位错误

### ❌ 错误 1: 混用单位

```python
# 设置单位为 kN-m-C
SapModel.SetPresentUnits(7)

# ❌ 错误：使用 mm 输入截面尺寸
SapModel.PropFrame.SetRectangle('BEAM', 'C30', 300, 500)
# 实际创建了 300m x 500m 的梁！
```

**正确做法**:
```python
# ✅ 方法 1: 使用 m
SapModel.PropFrame.SetRectangle('BEAM', 'C30', 0.3, 0.5)

# ✅ 方法 2: 切换到 N-mm-C
SapModel.SetPresentUnits(11)
SapModel.PropFrame.SetRectangle('BEAM', 'C30', 300, 500)
```

### ❌ 错误 2: 材料属性单位错误

```python
# 设置单位为 kN-m-C
SapModel.SetPresentUnits(7)

# ❌ 错误：弹性模量使用 MPa
E = 30000  # MPa
SapModel.PropMaterial.SetMPIsotropic('C30', E, 0.2, 1e-5)
# 实际弹性模量只有 30000 kN/m² = 30 MPa，差了 1000 倍！
```

**正确做法**:
```python
# ✅ 正确：转换为 kN/m²
E = 30000 * 1000  # 30,000,000 kN/m²
SapModel.PropMaterial.SetMPIsotropic('C30', E, 0.2, 1e-5)
```

### ❌ 错误 3: 荷载单位错误

```python
# 设置单位为 kN-m-C
SapModel.SetPresentUnits(7)

# ❌ 错误：荷载单位为 N/mm (虽然数值与 kN/m 相同)
distributed_load = 20  # 以为是 kN/m
# 但如果代码中有其他地方的单位混淆，可能导致错误
```

**正确做法**:
```python
# ✅ 明确注释单位
distributed_load_kN_m = 20  # kN/m
SapModel.FrameObj.SetLoadDistributed(frame, 'LIVE', 1, 3, 0, 1,
                                      distributed_load_kN_m,
                                      distributed_load_kN_m, 'Local')
```

## 验证单位设置

### 检查当前单位

```python
# 获取当前单位
units = SapModel.GetPresentUnits()
print(f"当前单位代码: {units}")

if units == 7:
    print("当前单位: kN, m, C")
elif units == 11:
    print("当前单位: N, mm, C")
```

### 验证输入值

```python
# 在关键步骤后打印参数进行验证
print(f"梁截面: {width} m × {height} m")
print(f"弹性模量: {E/1000:.0f} MPa ({E} kN/m²)")
print(f"均布荷载: {load} kN/m")
print(f"节点坐标: ({x} m, {y} m, {z} m)")
```

## 建议的最佳实践

### 1. 始终在脚本开始时设置单位

```python
def create_model():
    # 连接到 SAP2000
    ...

    # ⚠️ 第一步：设置单位系统
    kN_m_C = 7
    SapModel.SetPresentUnits(kN_m_C)
    print("✓ 单位系统: kN, m, C")

    # 然后进行其他操作
    ...
```

### 2. 在注释中明确单位

```python
# ✅ 好的注释
beam_width = 0.3      # m
beam_height = 0.5     # m
E = 30000000          # kN/m² (= 30000 MPa)
load = 20             # kN/m

# ❌ 不好的注释
beam_width = 0.3      # 宽度
beam_height = 0.5     # 高度
E = 30000000          # 弹性模量
load = 20             # 荷载
```

### 3. 使用单位转换函数

```python
def MPa_to_kN_m2(MPa):
    """将 MPa 转换为 kN/m²"""
    return MPa * 1000

def mm_to_m(mm):
    """将 mm 转换为 m"""
    return mm / 1000

# 使用
E = MPa_to_kN_m2(30000)  # 30,000,000 kN/m²
width = mm_to_m(300)     # 0.3 m
```

### 4. 创建单位检查函数

```python
def verify_unit_system(sap_model, expected_units=7):
    """验证单位系统是否正确"""
    current = sap_model.GetPresentUnits()
    if current != expected_units:
        print(f"⚠️ 警告: 当前单位代码为 {current}，期望 {expected_units}")
        return False
    return True

# 使用
if not verify_unit_system(SapModel, 7):
    print("请修正单位设置！")
```

---

**总结**: 单位一致性是 SAP2000 API 编程中最容易出错的地方。始终：
1. ✅ 明确设置单位系统
2. ✅ 在注释中标明单位
3. ✅ 使用转换函数
4. ✅ 验证关键参数的单位
